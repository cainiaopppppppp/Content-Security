# 2021302181152 邓鹏 实验二

## 1. 数据集

UrbanSound8K

下载链接 `https://www.kaggle.com/datasets/chrisfilo/urbansound8k`

## 2. 代码文件介绍

### · wav音频的声谱图特征

`1.py` 执行后生成声谱图并存储为`1.png`

### · CNN在UrbanSound8K数据集上完成音频分类任务

`2.ipynb` 执行后可以看到训练的详细过程，结果存储在`UrbanSound8kResults.csv`中