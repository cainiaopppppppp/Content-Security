# 2021302181152 邓鹏 实验一

# 1. 数据集

## INRIAPerson

下载链接： ftp://ftp.inrialpes.fr/pub/lear/douze/data/INRIAPerson.tar

# 2. 文件介绍

## HOG+SVM行人检测

`1.1.ipynb` 修改相关代码路径即可执行

训练生成的模型 `svm_hog.xml` 已给出

## yolo V8-PyTorch完成图像目标检测任务

先执行 `onn.py` 生成 `yolov8n.onnx` 和 `yolov8n.pt`

再执行`1.2.py` 修改相关代码路径即可执行完成目标检测任务